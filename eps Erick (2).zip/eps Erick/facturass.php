<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Facturas</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="flex flex-col items-center bg-gray-100 text-gray-800 min-h-screen">

<?php
    // Conexión a la base de datos (una sola conexión)
    $conn = new mysqli('localhost', 'root', '', 'EpsErick1');
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Obtener clientes
    $queryClientes = "SELECT id_cliente, CONCAT(nombre, ' ', apellido) AS nombreCompleto FROM clientes";
    $resultadoClientes = $conn->query($queryClientes);

    // Obtener productos
    $queryProductos = "SELECT id_producto, nombre_producto FROM productos";
    $resultadoProductos = $conn->query($queryProductos);
?>

<div class="container">
    <!-- Menú de Navegación -->
    <nav class="bg-gray-800 w-full p-4 rounded-lg shadow-md sticky top-0 z-10">
        <ul class="flex justify-center space-x-8">
            <li>
                <a href="clientes.html" class="text-white font-semibold hover:text-blue-400 transition duration-200">Clientes</a>
            </li>
            <li>
                <a href="productos.html" class="text-white font-semibold hover:text-blue-400 transition duration-200">Productos</a>
            </li>
            <li>
                <a href="index.html" class="text-white font-semibold hover:text-blue-400 transition duration-200">Menú</a>
            </li>
        </ul>
    </nav>
</div>

<!-- Contenedor del Formulario -->
<div class="container mt-10">
    <div class="bg-white p-8 rounded-2xl shadow-lg max-w-lg mx-auto">
        <h2 class="text-2xl font-bold text-center text-gray-900 mb-6">Gestionar Facturas</h2>
        <form action="facturas.php" method="POST" class="space-y-6">
            <!-- Cliente -->
            <div>
                <label for="id_cliente" class="block text-sm font-medium text-gray-700 mb-1">Cliente</label>
                <select name="id_cliente" id="id_cliente" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-500 focus:outline-none">
                    <?php
                    // Agregar opciones al select de clientes
                    if ($resultadoClientes->num_rows > 0) {
                        while ($row = $resultadoClientes->fetch_assoc()) {
                            echo "<option value='" . $row['id_cliente'] . "'>" . $row['nombreCompleto'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No hay clientes disponibles</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Producto -->
            <div>
                <label for="id_producto" class="block text-sm font-medium text-gray-700 mb-1">Producto</label>
                <select name="id_producto" id="id_producto" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-500 focus:outline-none">
                    <?php
                    // Agregar opciones al select de productos
                    if ($resultadoProductos->num_rows > 0) {
                        while ($row = $resultadoProductos->fetch_assoc()) {
                            echo "<option value='" . $row['id_producto'] . "'>" . $row['nombre_producto'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No hay productos disponibles</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Cantidad -->
            <div>
                <label for="cantidad" class="block text-sm font-medium text-gray-700 mb-1">Cantidad</label>
                <input type="number" name="cantidad" id="cantidad" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-500 focus:outline-none" placeholder="Ingrese la cantidad">
            </div>

            <!-- Valor Total -->
            <div>
                <label for="valor_total" class="block text-sm font-medium text-gray-700 mb-1">Valor Total</label>
                <input type="number" name="valor_total" id="valor_total" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-500 focus:outline-none" placeholder="Ingrese el valor total">
            </div>

            <!-- Botones CRUD -->
            <div class="grid grid-cols-2 gap-4">
                <button type="submit" name="accion" value="create" class="bg-green-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-green-600 transition duration-200">Crear</button>
                <button type="submit" name="accion" value="read" class="bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-200">Buscar</button>
                <button type="submit" name="accion" value="update" class="bg-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-yellow-600 transition duration-200">Actualizar</button>
                <button type="submit" name="accion" value="delete" class="bg-red-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-red-600 transition duration-200">Eliminar</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
