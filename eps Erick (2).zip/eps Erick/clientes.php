<?php
$host = 'localhost';
$dbname = 'EpsErick1';
$usuario = 'root';
$contraseña = '';



try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $usuario, $contraseña);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("¡Error en la conexión a la base de datos!: " . $e->getMessage());
}

/* Crear la tabla Productos si no existe
try {
    $sql = "CREATE TABLE IF NOT EXISTS Productos (
                id_producto INT AUTO_INCREMENT PRIMARY KEY,
                nombre_producto VARCHAR(100) NOT NULL,
                lote_producto VARCHAR(50) NOT NULL,
                valor DECIMAL(10, 2) NOT NULL
            )";
    $pdo->exec($sql);
    echo "Tabla 'Productos' creada o ya existe.<br>";
} catch (PDOException $e) {
    echo "Error al crear la tabla 'Productos': " . $e->getMessage() . "<br>";
}

// Crear la tabla Clientes si no existe (puede que falte en el código original)
try {
    $sql = "CREATE TABLE IF NOT EXISTS Clientes (
                id_cliente INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) NOT NULL,
                apellido VARCHAR(100) NOT NULL,
                tipo_documento VARCHAR(50) NOT NULL,
                numero_documento VARCHAR(50) UNIQUE NOT NULL,
                telefono VARCHAR(50) NOT NULL,
                fechnacimiento DATE NOT NULL
            )";
    $pdo->exec($sql);
    echo "Tabla 'Clientes' creada o ya existe.<br>";
} catch (PDOException $e) {
    echo "Error al crear la tabla 'Clientes': " . $e->getMessage() . "<br>";
}

// Crear la tabla Facturas si no existe
try {
    $sql = "CREATE TABLE IF NOT EXISTS Facturas (
                id_factura INT AUTO_INCREMENT PRIMARY KEY,
                numero_factura VARCHAR(50) UNIQUE NOT NULL,
                id_cliente INT NOT NULL,
                id_producto INT NOT NULL,
                cantidad INT NOT NULL,
                valor_total DECIMAL(12, 2) NOT NULL,
                FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente),
                FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
            )";
    $pdo->exec($sql);
    echo "Tabla 'Facturas' creada o ya existe.<br>";
} catch (PDOException $e) {
    echo "Error al crear la tabla 'Facturas': " . $e->getMessage() . "<br>";
}
*/
// Funciones CRUD para Clientes
function crearCliente($pdo, $nombre, $apellido, $tipo_documento, $numero_documento, $telefono, $fechnacimiento) {
    try {
        $sql = "INSERT INTO Clientes (nombre, apellido, tipo_documento, numero_documento, telefono, fechnacimiento) 
                VALUES (:nombre, :apellido, :tipo_documento, :numero_documento, :telefono, :fechnacimiento)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':apellido', $apellido);
        $stmt->bindParam(':tipo_documento', $tipo_documento);
        $stmt->bindParam(':numero_documento', $numero_documento);
        $stmt->bindParam(':telefono', $telefono);
        $stmt->bindParam(':fechnacimiento', $fechnacimiento);
        $stmt->execute();
        echo "Cliente creado exitosamente.<br>";
        
    } catch (PDOException $e) {
        echo "Error al crear cliente: " . $e->getMessage() . "<br>";
    }
}

if (isset($_POST['accion']) && $_POST['accion'] === 'create') {
    crearCliente(
        $pdo,
        $_POST['nombre'],
        $_POST['apellido'],
        $_POST['tipo_documento'],
        $_POST['numero_documento'],
        $_POST['telefono'],
        $_POST['fechnacimiento']
    );
}



function leerCliente($pdo, $numero_documento) {
    try {
        $sql = "SELECT * FROM Clientes WHERE numero_documento = :numero_documento";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':numero_documento', $numero_documento);
        $stmt->execute();
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($cliente) {
            echo "ID Cliente: " . $cliente['id_cliente'] . "<br>";
            echo "Nombre: " . $cliente['nombre'] . "<br>";
            echo "Apellido: " . $cliente['apellido'] . "<br>";
            echo "Tipo de Documento: " . $cliente['tipo_documento'] . "<br>";
            echo "Número de Documento: " . $cliente['numero_documento'] . "<br>";
            echo "Teléfono: " . $cliente['telefono'] . "<br>";
            echo "Fecha de Nacimiento: " . $cliente['fechnacimiento'] . "<br><br>";
        } else {
            echo "No se encontró un cliente con el número de documento proporcionado.<br>";
        }
    } catch (PDOException $e) {
        echo "Error al buscar cliente: " . $e->getMessage() . "<br>";
    }
}

function actualizarCliente($pdo, $numero_documento, $nombre, $apellido, $telefono) {
    try {
        $sql = "UPDATE Clientes 
                SET nombre = :nombre, apellido = :apellido, telefono = :telefono 
                WHERE numero_documento = :numero_documento";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':numero_documento', $numero_documento);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':apellido', $apellido);
        $stmt->bindParam(':telefono', $telefono);
        $stmt->bindParam(':fechnacimiento', $fechnacimiento);
        $stmt->bindParam(':tipo_documento', $tipo_documento);
        $stmt->bindParam(':numero_documento', $numero_documento);
        $stmt->execute();

        if ($stmt->execute()) {
            echo "Cliente actualizado exitosamente.<br>";
        } else {
            echo "Error al actualizar cliente.<br>";
        }
    } catch (PDOException $e) {
        echo "Error al actualizar cliente: " . $e->getMessage() . "<br>";
    }
}

function eliminarCliente($pdo, $numero_documento) {
    try {
        $sql = "DELETE FROM Clientes WHERE numero_documento = :numero_documento";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':numero_documento', $numero_documento);

        if ($stmt->execute()) {
            echo "Cliente eliminado exitosamente.<br>";
        } else {
            echo "Error al eliminar cliente.<br>";
        }
    } catch (PDOException $e) {
        echo "Error al eliminar cliente: " . $e->getMessage() . "<br>";
    }
}