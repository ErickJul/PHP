<?php
// Funciones CRUD para Facturas

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Configuración de conexión a la base de datos
$host = 'localhost';
$dbname = 'EpsErick1';
$usuario = 'root';
$contraseña = '';

try {
    // Crear una nueva conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $usuario, $contraseña);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("¡Error en la conexión a la base de datos!: " . $e->getMessage());
}

$conn = new mysqli($servidor, $usuario, $password, $bd);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$accion = $_POST['accion'] ?? '';
$id_cliente = $_POST['id_cliente'] ?? null;
$id_producto = $_POST['id_producto'] ?? null;
$cantidad = $_POST['cantidad'] ?? null;
$valor_total = $_POST['valor_total'] ?? null;

switch ($accion) {
    case 'create': // Crear factura
        if ($id_cliente && $id_producto && $cantidad && $valor_total) {
            $sql = "INSERT INTO facturas (id_cliente, id_producto, cantidad, valor_total) 
                    VALUES ('$id_cliente', '$id_producto', '$cantidad', '$valor_total')";
            if ($conn->query($sql) === TRUE) {
                echo "Factura creada exitosamente.";
            } else {
                echo "Error al crear la factura: " . $conn->error;
            }
        } else {
            echo "Por favor, complete todos los campos.";
        }
        break;

    case 'read': // Leer factura
        if ($id_cliente && $id_producto) {
            $sql = "SELECT * FROM facturas WHERE id_cliente = '$id_cliente' AND id_producto = '$id_producto'";
            $resultado = $conn->query($sql);

            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {
                    echo "Cliente: " . $fila['id_cliente'] . "<br>";
                    echo "Producto: " . $fila['id_producto'] . "<br>";
                    echo "Cantidad: " . $fila['cantidad'] . "<br>";
                    echo "Valor Total: " . $fila['valor_total'] . "<br><hr>";
                }
            } else {
                echo "No se encontraron facturas para los datos ingresados.";
            }
        } else {
            echo "Por favor, ingrese el ID del cliente y producto para buscar.";
        }
        break;

    case 'update': // Actualizar factura
        if ($id_cliente && $id_producto && $cantidad && $valor_total) {
            $sql = "UPDATE facturas SET cantidad = '$cantidad', valor_total = '$valor_total' 
                    WHERE id_cliente = '$id_cliente' AND id_producto = '$id_producto'";
            if ($conn->query($sql) === TRUE) {
                echo "Factura actualizada exitosamente.";
            } else {
                echo "Error al actualizar la factura: " . $conn->error;
            }
        } else {
            echo "Por favor, complete todos los campos para actualizar.";
        }
        break;

    case 'delete': // Eliminar factura
        if ($id_cliente && $id_producto) {
            $sql = "DELETE FROM facturas WHERE id_cliente = '$id_cliente' AND id_producto = '$id_producto'";
            if ($conn->query($sql) === TRUE) {
                echo "Factura eliminada exitosamente.";
            } else {
                echo "Error al eliminar la factura: " . $conn->error;
            }
        } else {
            echo "Por favor, ingrese el ID del cliente y producto para eliminar.";
        }
        break;

    default:
        echo "Acción no válida.";
        break;
}

$conn->close();
?>
