<?php
// Datos de conexión a la base de datos
$host = 'localhost';
$dbname = 'EpsErick1';
$usuario = 'root';
$contraseña = '';

try {
    // Crear una nueva conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $usuario, $contraseña);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("¡Error en la conexión a la base de datos!: " . $e->getMessage());
}

// Funciones CRUD para Productos
function crearProducto($pdo, $nombre_producto, $lote_producto, $valor) {
    try {
        $sql = "INSERT INTO Productos (nombre_producto, lote_producto, valor) 
                VALUES (:nombre_producto, :lote_producto, :valor)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nombre_producto', $nombre_producto);
        $stmt->bindParam(':lote_producto', $lote_producto);
        $stmt->bindParam(':valor', $valor);
        $stmt->execute();
        echo "Producto creado exitosamente.<br>";
    } catch (PDOException $e) {
        echo "Error al crear producto: " . $e->getMessage() . "<br>";
    }
}

if (isset($_POST['accion']) && $_POST['accion'] === 'create') {
    crearProducto(
        $pdo,  // Pasando la conexión PDO correctamente
        $_POST['nombre_producto'],
        $_POST['lote_producto'],
        $_POST['valor']
    );
}  

function leerProducto($pdo, $id_producto) {
    try {
        $sql = "SELECT * FROM Productos WHERE id_producto = :id_producto";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id_producto', $id_producto);
        $stmt->execute();
        $producto = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($producto) {
            echo "ID Producto: " . $producto['id_producto'] . "<br>";
            echo "Nombre Producto: " . $producto['nombre_producto'] . "<br>";
            echo "Lote Producto: " . $producto['lote_producto'] . "<br>";
            echo "Valor: " . $producto['valor'] . "<br><br>";
        } else {
            echo "No se encontró un producto con el ID proporcionado.<br>";
        }
    } catch (PDOException $e) {
        echo "Error al buscar producto: " . $e->getMessage() . "<br>";
    }
}

function actualizarProducto($pdo, $id_producto, $nombre_producto, $lote_producto, $valor) {
    try {
        $sql = "UPDATE Productos 
                SET nombre_producto = :nombre_producto, lote_producto = :lote_producto, valor = :valor
                WHERE id_producto = :id_producto";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id_producto', $id_producto);
        $stmt->bindParam(':nombre_producto', $nombre_producto);
        $stmt->bindParam(':lote_producto', $lote_producto);
        $stmt->bindParam(':valor', $valor);

        if ($stmt->execute()) {
            echo "Producto actualizado exitosamente.<br>";
        } else {
            echo "Error al actualizar producto.<br>";
        }
    } catch (PDOException $e) {
        echo "Error al actualizar producto: " . $e->getMessage() . "<br>";
    }
}

function eliminarProducto($pdo, $id_producto) {
    try {
        $sql = "DELETE FROM Productos WHERE id_producto = :id_producto";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id_producto', $id_producto);

        if ($stmt->execute()) {
            echo "Producto eliminado exitosamente.<br>";
        } else {
            echo "Error al eliminar producto.<br>";
        }
    } catch (PDOException $e) {
        echo "Error al eliminar producto: " . $e->getMessage() . "<br>";
    }
}